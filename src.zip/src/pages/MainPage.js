import { Link } from "react-router-dom";


function MainPage() {
  return (
    <div>
      
      <div>
      </div>
    </div>
  );
}

export default MainPage;
